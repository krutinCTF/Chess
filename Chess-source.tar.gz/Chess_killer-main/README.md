# Chess Overlay

Android overlay prototype built with Kotlin, Android Gradle Plugin 8.0.2 and JDK 17.

## Build

```bash
gradle --no-daemon assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.
GitHub Actions also builds this APK on every push to `main` and uploads it as the
`chess-overlay-debug-apk` workflow artifact.

## Current limitations

This repository is a prototype, not a working chess-analysis assistant yet:

- Screen capture via MediaProjection is not implemented.
- Chessboard and piece recognition are not implemented.
- No Stockfish Android binary is bundled, so engine analysis is unavailable.

The app deliberately reports that no position is available instead of inventing
a starting-position FEN and suggesting a misleading move.
