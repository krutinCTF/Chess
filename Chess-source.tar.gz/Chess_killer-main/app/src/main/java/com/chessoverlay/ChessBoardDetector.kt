package com.chessoverlay

import android.graphics.Bitmap

/**
 * Chessboard recognition is intentionally not faked. The previous implementation
 * returned the initial-position FEN for every screenshot, which could produce
 * completely unrelated moves. A real detector/model must be integrated here.
 */
class ChessBoardDetector {
    fun detectBoardAndExtractFEN(screenshot: Bitmap): String? = null
}
